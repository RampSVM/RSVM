function PredictY = RSVMC(TestX,DataTrain,FunPara)

%% Initiation
Train.X = DataTrain.X;Train.Y = DataTrain.Y;
clear DataTrain

% Model.name = 'RampSVM';
% Model.Classifier = @RampSVM;
% Model.trainFun = @train_RampSVM;
% Model.classifyFun = @classify_RampSVM;

%% train_RampSVM

Ylabel = unique(Train.Y);
nclass = length(Ylabel);
if nclass == 2
%     tic,
%     indi = find(Train.Y==Ylabel(1));
%     indj = find(Train.Y~=Ylabel(1));
%     SubTrain.X = [Train.X(indi,:); Train.X(indj,:)];
%     SubTrain.Y = [ones(length(indi),1); -ones(length(indj),1)];
%     [w,b,SV] = RampSVMCCCP(SubTrain,FunPara);
    [w,b,SV] = RampSVMCCCP(Train,FunPara);
%     Times = toc;
else 
    w = cell(nclass,1);
    b = cell(nclass,1);
    SV = cell(nclass,1);
%     tic,
    for i = 1:nclass
%         indi = find(Train.Y==Ylabel(i));
%         indj = find(Train.Y~=Ylabel(i));
%         SubTrain.X = [Train.X(indi,:); Train.X(indj,:)];
%         SubTrain.Y = [ones(length(indi),1); -ones(length(indj),1)];
%         [w{i},b{i},SV{i}] = RampSVMCCCP(SubTrain,FunPara);
        [w{i},b{i},SV{i}] = RampSVMCCCP(Train,FunPara);
    end
%     Times = toc;
end

% Model.nclass = nclass;
% Model.w = w;
% Model.b = b;
% Model.SV = SV;
% Model.Times = Times;



%% predict_RampSVM

% nclass = Model.nclass;
% w = Model.w;
% b = Model. b;
% SV = Model.SV;
% FunPara = Model.FunPara;
% kernel_fun = FunPara.kernel_fun; 
n = size(TestX,1);

if nclass == 2
    if strcmp(FunPara.kerfPara.type,'lin')
        Result.Y = TestX * w + b;
    elseif strcmp(FunPara.kerfPara.type,'rbf')
        Ktest = kernelfun(SV.X,kernel_fun,TestX);
        Result.Y = Ktest' * w;
    end
    PredictY = ones(n,1);
    PredictY(Result.Y < 0) = -1;
else
    d = zeros(n,nclass);
    for i=1:nclass
        w_aux = w{i};
        b_aux = b{i};
        SV_aux = SV{i};
        if strcmp(FunPara.kerfPara.type,'lin')
            d(:,i) = TestX * w_aux + b_aux;
        elseif strcmp(FunPara.kerfPara.type,'rbf')
            Ktest = kernelfun(SV_aux.X,kernel_fun,TestX);
            d(:,i) = Ktest' * w_aux;
        end
    end

    [~,PredictY] = min(abs(d),[],2);
%     Result.Y = abs(d(:,1)) - abs(d(:,2));
end

%     ll = length(find(PredictY-Test.Y==0));
%     accuracy = ll*100/(length(PredictY));
%     Result.Acc = accuracy;
%     Result.PredictY = PredictY;
%     Result.d = Result.Y;


end
