function [w,b,SV,iter,output1] = RampSVMCCCP(SubTrain,FunPara)
% The core training procedure for RampSVM
% Modified by Wei-Jie Chen, ZJUT, 2017.

kernel_fun = FunPara.kerfPara;

c1 = FunPara.p1;
s = FunPara.p2;
X = SubTrain.X;
Y = SubTrain.Y;
% diag_Y = diag(Y);
% Q  = diag_Y * kernelfun(X,kernel_fun) * diag_Y;
Q=(Y*Y').*kernelfun(X,kernel_fun);

Q=(Q+Q')/2;
n = size(Q,1);
beta = zeros(n,1);
e = -ones(n,1);
iter = 1;
Maxiter = 1000;
output1=[];
while iter < Maxiter
    LB = zeros(n,1) - beta;
    UB = c1*ones(n,1) - beta;

  [alpha,fval,exitflag,output,lambda] = quadprog(Q,e,[],[],Y',0.0,LB,UB,[],optimset('Display','off'));
    tt = find(abs(alpha)> 10^-6);
    output1=[output1;output];
    SV.X = X(tt,:);
    SV.Y = Y(tt);
    alpha = alpha(tt);
    SV.n = length(tt);
    ss(iter) =length(tt);

    bb = alpha < (c1 - 10^-6);

    New_beta = zeros(n,1);
    if strcmp(kernel_fun.type,'lin')
        w = SV.X' * (alpha .* SV.Y);
        b = mean(SV.Y(bb) - SV.X(bb,:) * w);
        Temp_Y = (X * w + b) .* Y;
        New_beta(Temp_Y < s) = c1;
    elseif strcmp(kernel_fun.type,'rbf')
        w = alpha .* SV.Y; 
        b = mean(SV.Y(bb) - kernelfun(SV.X,kernel_fun,SV.X(bb,:))' * w);
        Temp_Y = (kernelfun(SV.X,kernel_fun,X)' * w + b) .* Y;
        New_beta(Temp_Y < s) = c1;
    end

    if norm(New_beta - beta) < 10^-5
        break;
    else
        beta = New_beta;
        iter = iter+1;
    end
end
SV.s=ss;
aa = (X * w + b) .* Y;
ramp = @(z) max(1-z,0) + min(1+z,0);
fval = 1/2 * (norm(w)^2) + c1 * sum(ramp(aa));
end