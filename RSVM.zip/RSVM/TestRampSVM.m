
clear
clc
%load data

load Austrain

SubTrain.X=X;
SubTrain.Y=Y;
C=0.2;
%parameter setting
FunPara.kerfPara.type='lin'; % 'rbf' ...
FunPara.kerfPara.pars=1; % if necessary(rho in 'rbf')
FunPara.p1=C;
FunPara.p2=0.5; % s=(0,1) in ramp loss

% compute w,b,
tic
[w,b,SV] = RampSVMCCCP(SubTrain,FunPara);
t2=toc;
% predicting is same as SVM (also can see RSVMC,which could be used for multiclass classification)

     test_label=Y; test_data=X;
Ah = test_label.*test_data;%�������ݼ�ΪAt.
       h  = Ah*w + b*test_label;
       h1 = (h>0);
     sum1 = sum(h1);
     hnnz = size(test_label,1);
     Hrate = sum1/hnnz;



